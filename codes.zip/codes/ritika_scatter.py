# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 18:25:03 2018

@author: Elcot
"""

import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe
df=pd.read_csv("forest_area.txt", header=None, names=['col1', 'col2'])

#plot scatter with first column as x values and second column as y values
plt.scatter(df['col1'],df['col2'],color='#dd12dd',label="scatter-label")

#specifying labels
plt.xlabel("Area of the state")
plt.ylabel("Forest area of the state")

#enable legend
plt.legend()
plt.show()