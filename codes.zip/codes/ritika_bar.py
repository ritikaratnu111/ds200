# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 18:36:24 2018

@author: Elcot
"""

import pandas as pd
import matplotlib.pyplot as plt
import sys


#reading data frame from a csv file
df=pd.read_csv("forex.txt", header=None, names=['col1'])

#plot bar plot with xticks which is position of bars as first argument and height of bars as second argument
plt.bar([1,2,3,4,5,6,7,8,9,10,11,12,13],df['col1'],color='#ddbbaa',label="bar-label")

#specify labels on xticks
plt.xticks([1,2,3,4,5,6,7,8,9,10,11,12,13],["00","01","02","03","04","05","06","07","08","09","10","11","12"
])
plt.xlabel("Year 2000-2013")
plt.ylabel("Foreign Exchange Reserve in Rupee (Billion)")

#enabling legend
plt.legend()
plt.show()