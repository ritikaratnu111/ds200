# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 18:32:14 2018

@author: Elcot
"""

import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv
df=pd.read_csv("literacy.txt", header=None, names=['col1', 'col2'])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(df['col1'].dropna().tolist())
plotMap.append(df['col2'].dropna().tolist())

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2],["2001","2011"])
plt.xlabel("year")
plt.ylabel("literacy rate (of various states)")


plt.legend()
plt.show()